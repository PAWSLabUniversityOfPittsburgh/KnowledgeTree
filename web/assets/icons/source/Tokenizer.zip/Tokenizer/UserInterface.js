
function tokenizeString()
  {
     var input = window.document.getElementById("input").value;
     var seperator = getString(window.document.getElementById("seperator").value);
     var trim = getString(window.document.getElementById("trim").value);
     var ignoreEmptyTokens = window.document.getElementById("ignoreEmptyTokens").checked;

     var output = input.tokenize(seperator, trim, ignoreEmptyTokens);

     var join = getString(window.document.getElementById("join").value);

     window.document.getElementById("output").value = output.join(join);
  }

function getString()
  {
     var myString = getString.arguments[0];

     while(myString.indexOf("\\n") != -1)
       myString = myString.replace("\\n","\n");

     while(myString.indexOf("\\f") != -1)
       myString = myString.replace("\\f","\f");

     while(myString.indexOf("\\b") != -1)
       myString = myString.replace("\\b","\b");

     while(myString.indexOf("\\r") != -1)
       myString = myString.replace("\\r","\r");

     while(myString.indexOf("\\t") != -1)
       myString = myString.replace("\\t","\t");

     return myString;
  }